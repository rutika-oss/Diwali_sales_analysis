🪔 Diwali Sales Analysis
📌 Overview

Analyzed Diwali sales data using Python and EDA to understand customer behavior and improve business decisions.

🛠️ Tools

Python, Pandas, NumPy, Matplotlib, Seaborn

🔍 Work Done
Data cleaning & preprocessing
Exploratory Data Analysis (EDA)
Visualization of sales trends
📊 Key Insights
Women (26–35) are top buyers
High sales in IT & Healthcare sectors
Top categories: Food, Clothing, Electronics
🚀 Outcome

Helped identify customer segments and boost marketing strategies.
